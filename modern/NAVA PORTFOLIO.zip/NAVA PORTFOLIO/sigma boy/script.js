// Complete Chess Game with Working Movement
document.addEventListener('DOMContentLoaded', function() {
    console.log("Loading Complete Chess Game...");
    
    // Game variables
    const canvas = document.getElementById('chessCanvas');
    const ctx = canvas.getContext('2d');
    const squareSize = 80;
    const boardSize = 8;
    
    let board = [];
    let selectedPiece = null;
    let validMoves = [];
    let currentPlayer = 'white';
    let gameOver = false;
    let boardFlipped = false;
    
    // Initialize game
    function initGame() {
        // Create initial board setup
        board = [
            ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
            ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
            ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R']
        ];
        
        // Draw initial board
        drawBoard();
        drawPieces();
        
        // Setup event listeners
        setupEventListeners();
    }
    
    // Draw the chess board
    function drawBoard() {
        for (let row = 0; row < boardSize; row++) {
            for (let col = 0; col < boardSize; col++) {
                const x = col * squareSize;
                const y = row * squareSize;
                
                // Alternate square colors
                ctx.fillStyle = (row + col) % 2 === 0 ? '#F0D9B5' : '#B58863';
                ctx.fillRect(x, y, squareSize, squareSize);
                
                // Draw square border
                ctx.strokeStyle = (row + col) % 2 === 0 ? '#D8C29D' : '#9C6F3A';
                ctx.lineWidth = 2;
                ctx.strokeRect(x + 1, y + 1, squareSize - 2, squareSize - 2);
            }
        }
        
        // Draw highlights for selected piece and valid moves
        if (selectedPiece) {
            const [row, col] = selectedPiece;
            drawSquareHighlight(row, col, '#FFD700', 3);
            
            // Draw valid move highlights
            for (const [r, c] of validMoves) {
                drawSquareHighlight(r, c, 'rgba(0, 255, 0, 0.3)', 2);
            }
        }
    }
    
    // Draw chess pieces
    function drawPieces() {
        for (let row = 0; row < boardSize; row++) {
            for (let col = 0; col < boardSize; col++) {
                const piece = board[row][col];
                if (piece) {
                    drawPiece(piece, row, col);
                }
            }
        }
    }
    
    // Draw a single piece
    function drawPiece(piece, row, col) {
        const displayRow = boardFlipped ? 7 - row : row;
        const displayCol = boardFlipped ? 7 - col : col;
        
        const x = displayCol * squareSize + squareSize / 2;
        const y = displayRow * squareSize + squareSize / 2;
        const radius = squareSize * 0.35;
        
        // Piece colors
        const isWhite = piece === piece.toUpperCase();
        ctx.fillStyle = isWhite ? '#FFFFFF' : '#000000';
        ctx.strokeStyle = isWhite ? '#333333' : '#666666';
        
        // Draw piece circle
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.stroke();
        
        // Draw piece symbol
        ctx.fillStyle = isWhite ? '#000000' : '#FFFFFF';
        ctx.font = `bold ${radius * 1.2}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Piece symbols
        const symbols = {
            'P': '♙', 'R': '♖', 'N': '♘', 'B': '♗', 'Q': '♕', 'K': '♔',
            'p': '♟', 'r': '♜', 'n': '♞', 'b': '♝', 'q': '♛', 'k': '♚'
        };
        
        ctx.fillText(symbols[piece] || piece, x, y);
    }
    
    // Draw square highlight
    function drawSquareHighlight(row, col, color, width) {
        const displayRow = boardFlipped ? 7 - row : row;
        const displayCol = boardFlipped ? 7 - col : col;
        
        const x = displayCol * squareSize;
        const y = displayRow * squareSize;
        
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.strokeRect(x + width/2, y + width/2, squareSize - width, squareSize - width);
    }
    
    // Get valid moves for a piece
    function getPieceMoves(row, col) {
        const piece = board[row][col];
        if (!piece) return [];
        
        const moves = [];
        const isWhite = piece === piece.toUpperCase();
        
        // Pawn moves
        if (piece.toLowerCase() === 'p') {
            const direction = isWhite ? -1 : 1;
            const startRow = isWhite ? 6 : 1;
            
            // Forward move
            if (isValidSquare(row + direction, col) && !board[row + direction][col]) {
                moves.push([row + direction, col]);
                
                // Double move from starting position
                if (row === startRow && !board[row + 2 * direction][col]) {
                    moves.push([row + 2 * direction, col]);
                }
            }
            
            // Diagonal captures
            const captureLeft = [row + direction, col - 1];
            const captureRight = [row + direction, col + 1];
            
            [captureLeft, captureRight].forEach(([r, c]) => {
                if (isValidSquare(r, c) && board[r][c]) {
                    const target = board[r][c];
                    if ((target === target.toUpperCase()) !== isWhite) {
                        moves.push([r, c]);
                    }
                }
            });
        }
        
        // Knight moves
        else if (piece.toLowerCase() === 'n') {
            const knightMoves = [
                [row - 2, col - 1], [row - 2, col + 1],
                [row - 1, col - 2], [row - 1, col + 2],
                [row + 1, col - 2], [row + 1, col + 2],
                [row + 2, col - 1], [row + 2, col + 1]
            ];
            
            knightMoves.forEach(([r, c]) => {
                if (isValidSquare(r, c)) {
                    const target = board[r][c];
                    if (!target || (target === target.toUpperCase()) !== isWhite) {
                        moves.push([r, c]);
                    }
                }
            });
        }
        
        // King moves
        else if (piece.toLowerCase() === 'k') {
            const kingMoves = [
                [row - 1, col - 1], [row - 1, col], [row - 1, col + 1],
                [row, col - 1], [row, col + 1],
                [row + 1, col - 1], [row + 1, col], [row + 1, col + 1]
            ];
            
            kingMoves.forEach(([r, c]) => {
                if (isValidSquare(r, c)) {
                    const target = board[r][c];
                    if (!target || (target === target.toUpperCase()) !== isWhite) {
                        moves.push([r, c]);
                    }
                }
            });
        }
        
        // Basic moves for other pieces (simplified)
        else {
            // Simple moves for rook, bishop, queen (just show they can move)
            const directions = {
                'r': [[-1, 0], [1, 0], [0, -1], [0, 1]],
                'b': [[-1, -1], [-1, 1], [1, -1], [1, 1]],
                'q': [[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]]
            };
            
            const pieceType = piece.toLowerCase();
            if (directions[pieceType]) {
                directions[pieceType].forEach(([dr, dc]) => {
                    let r = row + dr;
                    let c = col + dc;
                    
                    while (isValidSquare(r, c)) {
                        const target = board[r][c];
                        if (!target) {
                            moves.push([r, c]);
                        } else {
                            if ((target === target.toUpperCase()) !== isWhite) {
                                moves.push([r, c]);
                            }
                            break;
                        }
                        r += dr;
                        c += dc;
                    }
                });
            }
        }
        
        return moves;
    }
    
    // Check if square is valid
    function isValidSquare(row, col) {
        return row >= 0 && row < boardSize && col >= 0 && col < boardSize;
    }
    
    // Setup event listeners
    function setupEventListeners() {
        canvas.addEventListener('click', handleCanvasClick);
        
        // Setup control buttons
        document.querySelectorAll('.control-btn').forEach(btn => {
            btn.onclick = function() {
                if (this.textContent.includes('New')) newGame();
                if (this.textContent.includes('Undo')) undoMove();
                if (this.textContent.includes('Flip')) flipBoard();
                if (this.textContent.includes('Hint')) showHint();
            };
        });
    }
    
    // Handle canvas click
    function handleCanvasClick(e) {
        if (gameOver) return;
        
        const rect = canvas.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        // Get clicked square
        const col = Math.floor(x / squareSize);
        const row = Math.floor(y / squareSize);
        
        // Convert to board coordinates
        const boardRow = boardFlipped ? 7 - row : row;
        const boardCol = boardFlipped ? 7 - col : col;
        
        if (selectedPiece) {
            const [selectedRow, selectedCol] = selectedPiece;
            
            // Check if this is a valid move
            const isValidMove = validMoves.some(([r, c]) => 
                r === boardRow && c === boardCol
            );
            
            if (isValidMove) {
                // Make the move
                board[boardRow][boardCol] = board[selectedRow][selectedCol];
                board[selectedRow][selectedCol] = '';
                
                // Clear selection
                selectedPiece = null;
                validMoves = [];
                
                // Switch player
                currentPlayer = currentPlayer === 'white' ? 'black' : 'white';
                
                // Update player display
                updatePlayerDisplay();
                
                // Redraw
                drawBoard();
                drawPieces();
                return;
            }
            
            // Clicked on another piece or empty square
            selectedPiece = null;
            validMoves = [];
        }
        
        // Select a new piece
        const clickedPiece = board[boardRow][boardCol];
        if (clickedPiece) {
            const pieceColor = clickedPiece === clickedPiece.toUpperCase() ? 'white' : 'black';
            if (pieceColor === currentPlayer) {
                selectedPiece = [boardRow, boardCol];
                validMoves = getPieceMoves(boardRow, boardCol);
            }
        }
        
        // Redraw with highlights
        drawBoard();
        drawPieces();
    }
    
    // Update player display
    function updatePlayerDisplay() {
        const whitePlayer = document.getElementById('whitePlayer');
        const blackPlayer = document.getElementById('blackPlayer');
        
        if (currentPlayer === 'white') {
            whitePlayer.classList.add('active');
            blackPlayer.classList.remove('active');
        } else {
            whitePlayer.classList.remove('active');
            blackPlayer.classList.add('active');
        }
    }
    
    // Control functions
    function newGame() {
        initGame();
        currentPlayer = 'white';
        gameOver = false;
        updatePlayerDisplay();
        console.log("New game started!");
    }
    
    function undoMove() {
        // Simple undo - just reset selection for now
        selectedPiece = null;
        validMoves = [];
        drawBoard();
        drawPieces();
        console.log("Selection cleared");
    }
    
    function flipBoard() {
        boardFlipped = !boardFlipped;
        drawBoard();
        drawPieces();
        console.log("Board flipped");
    }
    
    function showHint() {
        // Simple hint - show all valid moves for current player
        selectedPiece = null;
        validMoves = [];
        
        // Find all moves for current player
        for (let row = 0; row < boardSize; row++) {
            for (let col = 0; col < boardSize; col++) {
                const piece = board[row][col];
                if (piece) {
                    const pieceColor = piece === piece.toUpperCase() ? 'white' : 'black';
                    if (pieceColor === currentPlayer) {
                        validMoves = validMoves.concat(getPieceMoves(row, col));
                    }
                }
            }
        }
        
        drawBoard();
        drawPieces();
        console.log("Showing all valid moves");
    }
    
    // Start the game
    initGame();
    updatePlayerDisplay();
    console.log("Chess game loaded successfully!");
});