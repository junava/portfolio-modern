// tetris-fixed-collision.js
class Tetris {
    constructor() {
        // Game settings
        this.COLS = 10;
        this.ROWS = 20;
        this.SIZE = 30;
        
        // Colors
        this.COLORS = [
            '#00FFFF', '#0000FF', '#FF8000', '#FFFF00',
            '#00FF00', '#800080', '#FF0000'
        ];
        
        // Pieces with initial rotations
        this.PIECES = [
            [[0,0,0,0],[1,1,1,1],[0,0,0,0],[0,0,0,0]], // I
            [[2,0,0],[2,2,2],[0,0,0]], // J
            [[0,0,3],[3,3,3],[0,0,0]], // L
            [[4,4],[4,4]], // O
            [[0,5,5],[5,5,0],[0,0,0]], // S
            [[0,6,0],[6,6,6],[0,0,0]], // T
            [[7,7,0],[0,7,7],[0,0,0]]  // Z
        ];
        
        // Game state
        this.reset();
        
        // DAS/ARR with tighter values for sharper feel
        this.DAS = 100;
        this.ARR = 16;
        this.keys = {};
        this.dasTimers = {};
        this.arrTimers = {};
        
        // Soft drop speed (1x to instant, where instant = 0)
        this.softDropMultiplier = 80; // Default 20x speed
        this.instantSoftDrop = false; // When set to "instant"
        
        // Controls
        this.controls = {
            left: 37, right: 39, rotate: 38, ccw: 90, rot180: 65,
            down: 40, hard: 32, hold: 67, pause: 80
        };
        
        // Next pieces queue (5 pieces preview)
        this.nextQueue = [];
        
        // Load saved controls and settings
        const savedControls = localStorage.getItem('tetris-controls');
        if (savedControls) this.controls = JSON.parse(savedControls);
        
        const savedSettings = localStorage.getItem('tetris-settings');
        if (savedSettings) {
            const settings = JSON.parse(savedSettings);
            this.DAS = settings.das || this.DAS;
            this.ARR = settings.arr || this.ARR;
            this.softDropMultiplier = settings.softDropMultiplier || this.softDropMultiplier;
            this.instantSoftDrop = settings.instantSoftDrop || this.instantSoftDrop;
        }
        
        // Initialize
        this.createUI();
        this.setupEvents();
        this.draw();
    }
    
    reset() {
        this.board = Array(this.ROWS).fill().map(() => Array(this.COLS).fill(0));
        this.score = 0;
        this.lines = 0;
        this.level = 1;
        this.time = 0;
        this.piecesPlaced = 0;
        this.active = false;
        this.paused = false;
        this.over = false;
        this.ghost = true;
        this.mode = 'endless';
        
        // Lock delay system
        this.lockDelay = 500;
        this.lockTimer = 0;
        
        // 7-bag
        this.bag = [];
        this.current = null;
        this.nextQueue = [];
        this.hold = null;
        this.canHold = true;
        this.lastPiecePlaced = 0;
        
        // Fill next queue
        for (let i = 0; i < 5; i++) {
            this.nextQueue.push(this.generatePiece());
        }
        
        // Timing
        this.speed = 1000;
        this.dropCounter = 0;
        this.lastTime = 0;
        this.lastSecond = 0;
        this.animationFrameId = null;
    }
    
    // ==================== ENHANCED DAS/ARR ====================
    updateDAS(time) {
        const now = time;
        
        // Left movement with improved responsiveness
        if (this.keys[this.controls.left]) {
            if (!this.dasTimers.left) {
                this.dasTimers.left = now;
                this.move(-1);
            }
            
            const held = now - this.dasTimers.left;
            if (held >= this.DAS) {
                if (!this.arrTimers.left) {
                    this.arrTimers.left = now;
                }
                
                const arrHeld = now - this.arrTimers.left;
                if (arrHeld >= this.ARR) {
                    this.move(-1);
                    this.arrTimers.left = now;
                }
            }
        } else {
            delete this.dasTimers.left;
            delete this.arrTimers.left;
        }
        
        // Right movement
        if (this.keys[this.controls.right]) {
            if (!this.dasTimers.right) {
                this.dasTimers.right = now;
                this.move(1);
            }
            
            const held = now - this.dasTimers.right;
            if (held >= this.DAS) {
                if (!this.arrTimers.right) {
                    this.arrTimers.right = now;
                }
                
                const arrHeld = now - this.arrTimers.right;
                if (arrHeld >= this.ARR) {
                    this.move(1);
                    this.arrTimers.right = now;
                }
            }
        } else {
            delete this.dasTimers.right;
            delete this.arrTimers.right;
        }
    }
    
    // ==================== PIECE GENERATION ====================
    generatePiece() {
        if (this.bag.length === 0) {
            // Create new 7-bag
            this.bag = [0,1,2,3,4,5,6];
            // Fisher-Yates shuffle
            for (let i = this.bag.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [this.bag[i], this.bag[j]] = [this.bag[j], this.bag[i]];
            }
        }
        
        const type = this.bag.shift();
        return {
            type: type,
            matrix: this.PIECES[type].map(row => [...row]),
            rotation: 0
        };
    }
    
    // ==================== FIXED COLLISION DETECTION ====================
    collision(piece = this.current, offsetX = 0, offsetY = 0) {
        if (!piece) return true;
        
        for (let y = 0; y < piece.matrix.length; y++) {
            for (let x = 0; x < piece.matrix[y].length; x++) {
                if (piece.matrix[y][x]) {
                    const boardX = piece.x + x + offsetX;
                    const boardY = piece.y + y + offsetY;
                    
                    // Check boundaries
                    if (boardX < 0 || boardX >= this.COLS || boardY >= this.ROWS) {
                        return true;
                    }
                    
                    // Check if piece is above the board (allowed for spawn)
                    if (boardY < 0) {
                        continue;
                    }
                    
                    // Check collision with existing blocks
                    if (this.board[boardY][boardX]) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    // ==================== POLISHED MOVEMENT ====================
    move(dir) {
        if (!this.active || this.paused || this.over || !this.current) return;
        
        this.current.x += dir;
        if (this.collision()) {
            this.current.x -= dir;
            this.lockTimer = Math.max(0, this.lockTimer - 50);
        } else {
            this.lockTimer = Math.max(0, this.lockTimer - 100);
        }
    }
    
    rotate(dir = 1) {
        if (!this.active || this.paused || this.over || !this.current) return;
        
        const oldMatrix = this.current.matrix.map(row => [...row]);
        const oldX = this.current.x;
        const oldY = this.current.y;
        const oldRotation = this.current.rotation || 0;
        let newRotation = oldRotation;
        
        if (dir === 1) newRotation = (oldRotation + 1) % 4;
        else if (dir === -1) newRotation = (oldRotation + 3) % 4;
        else if (dir === 2) newRotation = (oldRotation + 2) % 4;
        
        // Rotate matrix
        const size = this.current.matrix.length;
        const rotated = Array(size).fill().map(() => Array(size).fill(0));
        
        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                if (this.current.matrix[y][x]) {
                    if (dir === 1) {
                        rotated[x][size - 1 - y] = this.current.matrix[y][x];
                    } else if (dir === -1) {
                        rotated[size - 1 - x][y] = this.current.matrix[y][x];
                    } else if (dir === 2) {
                        rotated[size - 1 - y][size - 1 - x] = this.current.matrix[y][x];
                    }
                }
            }
        }
        
        this.current.matrix = rotated;
        this.current.rotation = newRotation;
        
        // Simple wall kick attempts (more reliable)
        const kickTests = [
            [0, 0],   // No kick
            [-1, 0],  // Left
            [1, 0],   // Right
            [0, -1],  // Up
            [0, 1]    // Down
        ];
        
        for (const [dx, dy] of kickTests) {
            this.current.x = oldX + dx;
            this.current.y = oldY + dy;
            if (!this.collision()) {
                this.lockTimer = Math.max(0, this.lockTimer - 150);
                return;
            }
        }
        
        // If no kick works, revert rotation
        this.current.matrix = oldMatrix;
        this.current.x = oldX;
        this.current.y = oldY;
        this.current.rotation = oldRotation;
    }
    
    // ==================== IMPROVED SOFT DROP ====================
    updateSoftDrop(deltaTime) {
        if (!this.keys[this.controls.down] || !this.current) return false;
        
        if (this.instantSoftDrop) {
            // Instant soft drop - move piece down continuously until collision
            this.current.y++;
            if (this.collision()) {
                this.current.y--;
                this.score += 1;
                return false;
            }
            this.score += 1;
            return true;
        } else {
            // Variable speed soft drop
            const softDropSpeed = this.speed / Math.max(1, this.softDropMultiplier);
            this.dropCounter += deltaTime;
            
            if (this.dropCounter > softDropSpeed) {
                this.current.y++;
                if (this.collision()) {
                    this.current.y--;
                    return false;
                }
                this.score += 1;
                this.dropCounter = 0;
                return true;
            }
        }
        return false;
    }
    
    hardDrop() {
        if (!this.active || this.paused || this.over || !this.current) return;
        
        let dropDistance = 0;
        while (!this.collision(this.current, 0, dropDistance + 1)) {
            dropDistance++;
        }
        
        this.score += dropDistance * 2;
        this.current.y += dropDistance;
        this.placePiece();
    }
    
    // ==================== GAME LOGIC ====================
    placePiece() {
    console.log("Placing piece...", this.current?.type); // DEBUG
    for (let y = 0; y < this.current.matrix.length; y++) {
        for (let x = 0; x < this.current.matrix[y].length; x++) {
            if (this.current.matrix[y][x]) {
                const boardY = this.current.y + y;
                const boardX = this.current.x + x;
                if (boardY >= 0 && boardX >= 0 && boardY < this.ROWS && boardX < this.COLS) {
                    console.log("Setting board at", boardY, boardX, "to", this.current.type + 1); // DEBUG
                    this.board[boardY][boardX] = this.current.type + 1;
                }
            }
        }
    }
    
    console.log("Piece placed. Calling resetPiece..."); // DEBUG
    this.piecesPlaced++;
    this.clearLines();
    this.resetPiece();
}
    
    clearLines() {
    let linesCleared = 0;
    
    // Check from bottom to top
    for (let y = this.ROWS - 1; y >= 0; y--) {
        if (this.board[y].every(cell => cell !== 0)) {
            // Remove the line
            this.board.splice(y, 1);
            // Add empty line at top
            this.board.unshift(Array(this.COLS).fill(0));
            // Since we removed a line, check the same index again
            // (because the line below moved up)
            y++;
            linesCleared++;
            this.lines++;
        }
    }
    
    if (linesCleared > 0) {
        const points = [0, 100, 300, 500, 800];
        this.score += points[linesCleared] * this.level;
        
        this.level = Math.floor(this.lines / 10) + 1;
        this.speed = Math.max(50, 1000 - (this.level - 1) * 75);
        
        if (this.mode === '40lines' && this.lines >= 40) {
            this.endGame(true);
        }
    }
    
    this.updateUI();
}
    
    resetPiece() {
    // Get next piece from queue
    console.log("resetPiece called. Next queue length:", this.nextQueue.length); // DEBUG
    const nextPiece = this.nextQueue.shift();
    if (!nextPiece) return;
    
    this.current = {
        ...nextPiece,
        x: Math.floor(this.COLS / 2) - Math.floor(nextPiece.matrix[0].length / 2),
        y: 0
    };
    
    // Add new piece to queue
    this.nextQueue.push(this.generatePiece());
    
    this.canHold = true;
    this.lockTimer = 0;
    
    // Check collision
    if (this.collision()) {
        this.current.y = -1;
        if (this.collision()) {
            this.endGame();
        }
    }
}
    
    holdPiece() {
        if (!this.active || this.paused || this.over || !this.canHold || !this.current) return;
        
        const currentTime = Date.now();
        // Prevent rapid hold spam
        if (currentTime - this.lastPiecePlaced < 100) return;
        
        if (!this.hold) {
            this.hold = this.current.type;
            this.resetPiece();
        } else {
            const temp = this.current.type;
            const holdMatrix = this.PIECES[this.hold].map(row => [...row]);
            this.current.type = this.hold;
            this.current.matrix = holdMatrix;
            this.current.x = Math.floor(this.COLS / 2) - Math.floor(holdMatrix[0].length / 2);
            this.current.y = 0;
            this.current.rotation = 0;
            this.hold = temp;
            
            if (this.collision()) {
                this.current.y = -1;
                if (this.collision()) {
                    this.endGame();
                    return;
                }
            }
        }
        
        this.canHold = false;
        this.lockTimer = Math.max(0, this.lockTimer - 50);
        this.updateUI();
    }
    
    // ==================== GAME LOOP ====================
    gameLoop(time = 0) {
        if (!this.active || this.over || this.paused) {
            if (this.animationFrameId) {
                cancelAnimationFrame(this.animationFrameId);
                this.animationFrameId = null;
            }
            return;
        }
        
        if (!this.animationFrameId) {
            this.animationFrameId = requestAnimationFrame((t) => this.gameLoop(t));
            return;
        }
        
        this.updateDAS(time);
        
        const deltaTime = time - this.lastTime;
        this.lastTime = time;
        
        // Update game time
        if (time - this.lastSecond >= 1000) {
            this.time++;
            this.lastSecond = time;
            this.updateUI();
        }
        
        // Normal gravity
        this.dropCounter += deltaTime;
        if (this.dropCounter > this.speed) {
            this.current.y++;
            if (this.collision()) {
                this.current.y--;
                this.lockTimer += deltaTime;
                if (this.lockTimer >= this.lockDelay) {
                    this.placePiece();
                }
            } else {
                this.lockTimer = Math.max(0, this.lockTimer - 33);
            }
            this.dropCounter = 0;
        }
        
        // Soft drop handling
        if (this.keys[this.controls.down]) {
            const softDropMoved = this.updateSoftDrop(deltaTime);
            if (softDropMoved) {
                this.lockTimer = Math.max(0, this.lockTimer - 16);
            }
        }
        
        // Draw everything
        if (this.current) {
        this.draw();
        this.drawNextQueue();
        this.drawHold();
    }
        
        this.animationFrameId = requestAnimationFrame((t) => this.gameLoop(t));
    }
    
    // ==================== UI AND SETTINGS ====================
    createUI() {
        document.body.innerHTML = `
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; font-family: monospace; }
                body { background: #111; color: white; padding: 20px; min-height: 100vh; display: flex; justify-content: center; align-items: center; }
                .container { display: flex; gap: 20px; max-width: 1200px; flex-wrap: wrap; }
                .panel { background: #1a1a1a; border: 1px solid #333; padding: 15px; margin-bottom: 15px; border-radius: 4px; }
                .title { color: #888; font-size: 12px; margin-bottom: 5px; text-transform: uppercase; }
                .value { font-size: 24px; font-weight: bold; }
                .progress { height: 4px; background: #222; margin-top: 8px; border-radius: 2px; }
                .progress-fill { height: 100%; background: #4CAF50; width: 0%; border-radius: 2px; }
                #game { background: #000; border: 2px solid #333; display: block; }
                button { background: #222; border: 1px solid #333; color: white; padding: 10px; cursor: pointer; width: 100%; margin-top: 5px; border-radius: 4px; transition: background 0.2s; }
                button:hover { background: #2a2a2a; }
                .primary { border-color: #4CAF50; color: #4CAF50; font-weight: bold; }
                #status { text-align: center; margin-bottom: 10px; height: 20px; font-weight: bold; }
                .controls-info { font-size: 11px; color: #666; line-height: 1.4; margin-top: 5px; }
                #modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); align-items: center; justify-content: center; z-index: 1000; }
                .modal-content { background: #222; border: 1px solid #333; padding: 25px; width: 450px; max-width: 90%; border-radius: 8px; max-height: 90vh; overflow-y: auto; }
                .modal-content h3 { color: white; margin: 0 0 20px 0; border-bottom: 1px solid #444; padding-bottom: 10px; }
                .key-display { background: #444; color: white; padding: 6px 12px; min-width: 80px; text-align: center; border-radius: 4px; }
                input[type="range"] { width: 100%; margin: 10px 0; background: #333; height: 6px; border-radius: 3px; }
                input[type="range"]::-webkit-slider-thumb { background: #4CAF50; width: 18px; height: 18px; border-radius: 50%; cursor: pointer; }
                .range-label { color: #ccc; margin: 10px 0 5px 0; display: flex; justify-content: space-between; }
                .control-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #333; }
                .control-label { color: white; font-size: 14px; }
                .mode-selector { display: flex; gap: 10px; margin-top: 15px; }
                .mode-btn { background: #333; border: 1px solid #444; padding: 8px 15px; cursor: pointer; border-radius: 4px; }
                .mode-btn.active { background: #4CAF50; border-color: #4CAF50; }
                .checkbox { display: flex; align-items: center; margin: 15px 0; }
                .checkbox input { margin-right: 10px; }
                .speed-display { font-size: 14px; color: #4CAF50; margin-left: 10px; }
                .setting-group { margin: 20px 0; padding: 15px; background: #252525; border-radius: 6px; }
                .setting-group h4 { color: #ddd; margin: 0 0 15px 0; font-size: 16px; }
                .hint { font-size: 12px; color: #888; margin-top: 5px; }
                .next-container { display: flex; flex-direction: column; gap: 5px; }
                .next-piece { display: flex; justify-content: center; align-items: center; height: 60px; }
                .next-piece canvas { background: #111; border: 1px solid #333; }
                #next-queue { display: flex; flex-direction: column; gap: 8px; }
                .debug { position: absolute; top: 10px; left: 10px; background: rgba(0,0,0,0.7); padding: 10px; font-size: 12px; }
            </style>
            
            <div class="container">
                <!-- Left Panel -->
                <div>
                    <div class="panel">
                        <div class="title">Hold</div>
                        <canvas id="hold" width="80" height="80"></canvas>
                    </div>
                    <div class="panel">
                        <div class="title">Score</div>
                        <div id="score" class="value">0</div>
                    </div>
                    <div class="panel">
                        <div class="title">Lines</div>
                        <div id="lines" class="value">0</div>
                        <div class="progress">
                            <div id="progress" class="progress-fill"></div>
                        </div>
                    </div>
                    <button id="controls-btn">Game Settings</button>
                </div>
                
                <!-- Center -->
                <div>
                    <div id="status">Ready</div>
                    <canvas id="game" width="300" height="600"></canvas>
                    <div style="display: flex; gap: 10px; margin-top: 15px;">
                        <button id="start-btn" class="primary">Start Game</button>
                        <button id="pause-btn">Pause/Resume</button>
                        <button id="reset-btn">Reset</button>
                    </div>
                    <div class="mode-selector">
                        <div class="mode-btn active" data-mode="endless">Endless</div>
                        <div class="mode-btn" data-mode="40lines">40 Lines</div>
                    </div>
                </div>
                
                <!-- Right Panel -->
                <div>
                    <div class="panel" style="min-height: 380px;">
                        <div class="title">Next Pieces</div>
                        <div id="next-queue"></div>
                    </div>
                    <div class="panel">
                        <div class="title">Time</div>
                        <div id="time" class="value">00:00</div>
                    </div>
                    <div class="panel">
                        <div class="title">Pieces Per Second</div>
                        <div id="pps" class="value">0.00</div>
                        <div class="controls-info">Pieces Placed: <span id="pieces-count">0</span></div>
                    </div>
                    <div class="panel">
                        <div class="title">Controls</div>
                        <div class="controls-info">
                            ←→ : Move (DAS: <span id="das-display">100ms</span>)<br>
                            ↑ : Rotate Clockwise<br>
                            Z : Rotate Counter-Clockwise<br>
                            A : Rotate 180°<br>
                            ↓ : Soft Drop (<span id="softdrop-display">20x</span>)<br>
                            Space : Hard Drop<br>
                            C : Hold Piece<br>
                            P : Pause Game
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Controls Modal -->
            <div id="modal">
                <div class="modal-content">
                    <h3>Game Settings</h3>
                    
                    <div class="setting-group">
                        <h4>Movement Settings</h4>
                        <div class="range-label">
                            <span>DAS (Delayed Auto Shift)</span>
                            <span id="das-value">100ms</span>
                        </div>
                        <input type="range" id="das-slider" min="30" max="200" value="100">
                        <div class="hint">Lower = faster initial response (jstris style)</div>
                        
                        <div class="range-label">
                            <span>ARR (Auto Repeat Rate)</span>
                            <span id="arr-value">16ms</span>
                        </div>
                        <input type="range" id="arr-slider" min="0" max="50" value="16">
                        <div class="hint">Lower = faster repeat after DAS</div>
                    </div>
                    
                    <div class="setting-group">
                        <h4>Soft Drop Settings</h4>
                        <div class="range-label">
                            <span>Soft Drop Speed</span>
                            <span id="softdrop-value">20x</span>
                        </div>
                        <input type="range" id="softdrop-slider" min="1" max="100" value="20">
                        <div class="hint">100x = near instant, 1x = normal gravity</div>
                        
                        <div class="checkbox">
                            <input type="checkbox" id="instant-softdrop">
                            <label for="instant-softdrop">Instant Soft Drop (tetr.io style)</label>
                            <span class="speed-display" id="instant-indicator">❌</span>
                        </div>
                        <div class="hint">When enabled, soft drop moves piece instantly until collision</div>
                    </div>
                    
                    <div class="setting-group">
                        <h4>Key Bindings</h4>
                        <div id="controls-list"></div>
                    </div>
                    
                    <div style="display: flex; gap: 10px; margin-top: 20px;">
                        <button id="save-controls" style="flex: 1; background: #4CAF50; border: none; color: white; padding: 12px;">Save Settings</button>
                        <button id="reset-defaults" style="flex: 1; background: #555; border: none; color: white; padding: 12px;">Reset Defaults</button>
                        <button id="close-modal" style="flex: 1; background: #666; border: none; color: white; padding: 12px;">Close</button>
                    </div>
                </div>
            </div>
        `;
        
        // Create canvas elements for next pieces
        this.createNextQueueCanvases();
        this.updateSettingsDisplay();
    }
    
    createNextQueueCanvases() {
        const queueContainer = document.getElementById('next-queue');
        if (!queueContainer) return;
        
        queueContainer.innerHTML = '';
        for (let i = 0; i < 5; i++) {
            const pieceContainer = document.createElement('div');
            pieceContainer.className = 'next-piece';
            
            const canvas = document.createElement('canvas');
            canvas.width = 80;
            canvas.height = 60;
            canvas.id = `next-piece-${i}`;
            
            pieceContainer.appendChild(canvas);
            queueContainer.appendChild(pieceContainer);
        }
    }
    
    updateSettingsDisplay() {
        const dasDisplay = document.getElementById('das-display');
        const softdropDisplay = document.getElementById('softdrop-display');
        
        if (dasDisplay) dasDisplay.textContent = this.DAS + 'ms';
        if (softdropDisplay) {
            softdropDisplay.textContent = this.instantSoftDrop ? 'INSTANT' : this.softDropMultiplier + 'x';
        }
    }
    
    setupEvents() {
        // Game buttons
        document.getElementById('start-btn').addEventListener('click', () => this.start());
        document.getElementById('pause-btn').addEventListener('click', () => this.pause());
        document.getElementById('reset-btn').addEventListener('click', () => {
            this.reset();
            this.draw();
            this.updateUI();
        });
        
        // Mode selection
        document.querySelectorAll('.mode-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.mode = e.target.dataset.mode;
                this.reset();
                this.updateUI();
            });
        });
        
        // Controls modal
        const controlsBtn = document.getElementById('controls-btn');
        const closeModal = document.getElementById('close-modal');
        const saveControls = document.getElementById('save-controls');
        const resetDefaults = document.getElementById('reset-defaults');
        const modal = document.getElementById('modal');
        
        if (controlsBtn) controlsBtn.addEventListener('click', () => this.showControls());
        if (closeModal) closeModal.addEventListener('click', () => {
            modal.style.display = 'none';
        });
        
        if (saveControls) saveControls.addEventListener('click', () => {
            localStorage.setItem('tetris-controls', JSON.stringify(this.controls));
            localStorage.setItem('tetris-settings', JSON.stringify({
                das: this.DAS,
                arr: this.ARR,
                softDropMultiplier: this.softDropMultiplier,
                instantSoftDrop: this.instantSoftDrop
            }));
            modal.style.display = 'none';
            this.updateSettingsDisplay();
        });
        
        if (resetDefaults) resetDefaults.addEventListener('click', () => {
            this.DAS = 100;
            this.ARR = 16;
            this.softDropMultiplier = 80;
            this.instantSoftDrop = false;
            
            this.controls = {
                left: 37, right: 39, rotate: 38, ccw: 90, rot180: 65,
                down: 40, hard: 32, hold: 67, pause: 80
            };
            
            this.showControls();
        });
        
        // Modal close on outside click
        if (modal) modal.addEventListener('click', (e) => {
            if (e.target.id === 'modal') {
                modal.style.display = 'none';
            }
        });
        
        // DAS/ARR sliders
        const dasSlider = document.getElementById('das-slider');
        const arrSlider = document.getElementById('arr-slider');
        const softdropSlider = document.getElementById('softdrop-slider');
        const instantSoftdrop = document.getElementById('instant-softdrop');
        
        if (dasSlider) {
            dasSlider.value = this.DAS;
            dasSlider.addEventListener('input', (e) => {
                this.DAS = parseInt(e.target.value);
                document.getElementById('das-value').textContent = this.DAS + 'ms';
            });
        }
        
        if (arrSlider) {
            arrSlider.value = this.ARR;
            arrSlider.addEventListener('input', (e) => {
                this.ARR = parseInt(e.target.value);
                document.getElementById('arr-value').textContent = this.ARR + 'ms';
            });
        }
        
        if (softdropSlider) {
            softdropSlider.value = this.softDropMultiplier;
            softdropSlider.addEventListener('input', (e) => {
                this.softDropMultiplier = parseInt(e.target.value);
                document.getElementById('softdrop-value').textContent = this.softDropMultiplier + 'x';
                
                // Disable instant when using slider
                if (this.instantSoftDrop && this.softDropMultiplier < 100) {
                    this.instantSoftDrop = false;
                    if (instantSoftdrop) instantSoftdrop.checked = false;
                    document.getElementById('instant-indicator').textContent = '❌';
                }
            });
        }
        
        if (instantSoftdrop) {
            instantSoftdrop.checked = this.instantSoftDrop;
            instantSoftdrop.addEventListener('change', (e) => {
                this.instantSoftDrop = e.target.checked;
                document.getElementById('instant-indicator').textContent = this.instantSoftDrop ? '✅' : '❌';
                
                if (this.instantSoftDrop) {
                    this.softDropMultiplier = 100;
                    if (softdropSlider) softdropSlider.value = 100;
                    document.getElementById('softdrop-value').textContent = 'INSTANT';
                }
            });
        }
        
        // Keyboard controls
        document.addEventListener('keydown', (e) => {
            this.keys[e.keyCode] = true;
            
            if (e.keyCode === this.controls.rotate) this.rotate(1);
            if (e.keyCode === this.controls.ccw) this.rotate(-1);
            if (e.keyCode === this.controls.rot180) {
                this.rotate(1);
                this.rotate(1);
            }
            if (e.keyCode === this.controls.hard) this.hardDrop();
            if (e.keyCode === this.controls.hold) this.holdPiece();
            if (e.keyCode === this.controls.pause) this.pause();
            
            if (Object.values(this.controls).includes(e.keyCode)) {
                e.preventDefault();
            }
        });
        
        document.addEventListener('keyup', (e) => {
            this.keys[e.keyCode] = false;
        });
        
        // Close modal on ESC
        document.addEventListener('keydown', (e) => {
            if (e.keyCode === 27) {
                modal.style.display = 'none';
            }
        });
    }
    
    showControls() {
        document.getElementById('das-slider').value = this.DAS;
        document.getElementById('arr-slider').value = this.ARR;
        document.getElementById('softdrop-slider').value = this.softDropMultiplier;
        document.getElementById('instant-softdrop').checked = this.instantSoftDrop;
        
        document.getElementById('das-value').textContent = this.DAS + 'ms';
        document.getElementById('arr-value').textContent = this.ARR + 'ms';
        document.getElementById('softdrop-value').textContent = this.instantSoftDrop ? 'INSTANT' : this.softDropMultiplier + 'x';
        document.getElementById('instant-indicator').textContent = this.instantSoftDrop ? '✅' : '❌';
        
        const controls = [
            {key: 'left', label: 'Move Left'},
            {key: 'right', label: 'Move Right'},
            {key: 'rotate', label: 'Rotate Clockwise'},
            {key: 'ccw', label: 'Rotate Counter-Clockwise'},
            {key: 'rot180', label: 'Rotate 180°'},
            {key: 'down', label: 'Soft Drop'},
            {key: 'hard', label: 'Hard Drop'},
            {key: 'hold', label: 'Hold Piece'},
            {key: 'pause', label: 'Pause Game'}
        ];
        
        const listHTML = controls.map(c => `
            <div class="control-item">
                <div class="control-label">${c.label}</div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div id="key-${c.key}" class="key-display">
                        ${this.getKeyName(this.controls[c.key])}
                    </div>
                    <button onclick="tetris.changeKey('${c.key}')" style="background: #555; border: none; color: white; padding: 6px 10px; border-radius: 4px; cursor: pointer;">
                        Change
                    </button>
                </div>
            </div>
        `).join('');
        
        document.getElementById('controls-list').innerHTML = listHTML;
        document.getElementById('modal').style.display = 'flex';
    }
    
    changeKey(action) {
        const msg = document.createElement('div');
        msg.style.cssText = 'background: #444; color: #4CAF50; padding: 12px; margin: 10px 0; text-align: center; border-radius: 4px;';
        msg.textContent = `Press any key for ${action}...`;
        
        document.getElementById('controls-list').prepend(msg);
        
        const listener = (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.controls[action] = e.keyCode;
            document.removeEventListener('keydown', listener);
            this.showControls();
        };
        
        document.addEventListener('keydown', listener, {once: true});
    }
    
    getKeyName(code) {
        const names = {
            8: 'Backspace', 9: 'Tab', 13: 'Enter', 16: 'Shift', 17: 'Ctrl', 18: 'Alt',
            27: 'Esc', 32: 'Space', 37: '←', 38: '↑', 39: '→', 40: '↓',
            65: 'A', 66: 'B', 67: 'C', 68: 'D', 69: 'E', 70: 'F', 71: 'G', 72: 'H',
            73: 'I', 74: 'J', 75: 'K', 76: 'L', 77: 'M', 78: 'N', 79: 'O', 80: 'P',
            81: 'Q', 82: 'R', 83: 'S', 84: 'T', 85: 'U', 86: 'V', 87: 'W', 88: 'X',
            89: 'Y', 90: 'Z'
        };
        return names[code] || `Key ${code}`;
    }
    
    // ==================== GAME CONTROL METHODS ====================
    start() {
    if (this.active && !this.over) return;
    
    this.reset();
    this.active = true;
    this.paused = false;
    this.over = false;
    
    // Make sure we get a piece from the queue
    const nextPiece = this.nextQueue.shift();
    this.current = {
        ...nextPiece,
        x: Math.floor(this.COLS / 2) - Math.floor(nextPiece.matrix[0].length / 2),
        y: 0
    };
    
    // Add new piece to replace the one we took
    this.nextQueue.push(this.generatePiece());
    
    this.updateUI();
    this.lastTime = performance.now();
    this.lastSecond = performance.now();
    this.gameLoop();
}
    
    pause() {
        if (!this.active || this.over) return;
        
        this.paused = !this.paused;
        if (!this.paused) {
            this.lastTime = performance.now();
            this.lastSecond = performance.now();
            this.gameLoop();
        }
        this.updateUI();
    }
    
    endGame(isWin = false) {
        this.active = false;
        this.over = true;
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
        this.updateUI();
    }
    
    // ==================== UI UPDATES ====================
    updateUI() {
        const scoreEl = document.getElementById('score');
        const linesEl = document.getElementById('lines');
        const levelEl = document.getElementById('level');
        const timeEl = document.getElementById('time');
        const ppsEl = document.getElementById('pps');
        const piecesEl = document.getElementById('pieces-count');
        const progressEl = document.getElementById('progress');
        const statusEl = document.getElementById('status');
        
        if (scoreEl) scoreEl.textContent = this.score.toLocaleString();
        if (linesEl) linesEl.textContent = this.lines;
        if (levelEl) levelEl.textContent = this.level;
        if (piecesEl) piecesEl.textContent = this.piecesPlaced;
        
        if (timeEl) {
            const minutes = Math.floor(this.time / 60);
            const seconds = this.time % 60;
            timeEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
        
        if (ppsEl && this.time > 0) {
            const pps = (this.piecesPlaced / this.time).toFixed(2);
            ppsEl.textContent = pps;
        }
        
        if (progressEl) {
            const progress = Math.min(100, (this.lines / 40) * 100);
            progressEl.style.width = `${progress}%`;
        }
        
        if (statusEl) {
            if (this.over) {
                statusEl.textContent = this.lines >= 40 ? '40 Lines Cleared!' : 'Game Over';
                statusEl.style.color = this.lines >= 40 ? '#4CAF50' : '#f44336';
            } else if (this.paused) {
                statusEl.textContent = 'Paused';
                statusEl.style.color = '#FF9800';
            } else if (this.active) {
                statusEl.textContent = 'Playing';
                statusEl.style.color = '#4CAF50';
            } else {
                statusEl.textContent = 'Ready';
                statusEl.style.color = '#fff';
            }
        }
    }
    
    // ==================== DRAWING METHODS ====================
    draw() {
        const canvas = document.getElementById('game');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const size = this.SIZE;
        
        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw board
        for (let y = 0; y < this.ROWS; y++) {
            for (let x = 0; x < this.COLS; x++) {
                if (this.board[y][x]) {
                    ctx.fillStyle = this.COLORS[this.board[y][x] - 1];
                    ctx.fillRect(x * size, y * size, size, size);
                    
                    ctx.fillStyle = '#ffffff30';
                    ctx.fillRect(x * size, y * size, size - 1, 2);
                    ctx.fillRect(x * size, y * size, 2, size - 1);
                    
                    ctx.strokeStyle = '#00000040';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(x * size, y * size, size, size);
                }
            }
        }
        
        // Draw ghost piece
        if (this.ghost && this.current) {
            const ghost = {
                ...this.current,
                y: this.current.y,
                matrix: this.current.matrix.map(row => [...row])
            };
            
            while (!this.collision(ghost, 0, 1)) {
                ghost.y++;
            }
            
            ctx.strokeStyle = '#ffffff80';
            ctx.lineWidth = 2;
            for (let y = 0; y < ghost.matrix.length; y++) {
                for (let x = 0; x < ghost.matrix[y].length; x++) {
                    if (ghost.matrix[y][x]) {
                        ctx.strokeRect(
                            (ghost.x + x) * size + 1,
                            (ghost.y + y) * size + 1,
                            size - 2,
                            size - 2
                        );
                    }
                }
            }
        }
        
        // Draw current piece
        if (this.current) {
            for (let y = 0; y < this.current.matrix.length; y++) {
                for (let x = 0; x < this.current.matrix[y].length; x++) {
                    if (this.current.matrix[y][x]) {
                        ctx.fillStyle = this.COLORS[this.current.type];
                        ctx.fillRect(
                            (this.current.x + x) * size,
                            (this.current.y + y) * size,
                            size,
                            size
                        );
                        
                        ctx.fillStyle = '#ffffff30';
                        ctx.fillRect(
                            (this.current.x + x) * size,
                            (this.current.y + y) * size,
                            size - 1,
                            2
                        );
                        ctx.fillRect(
                            (this.current.x + x) * size,
                            (this.current.y + y) * size,
                            2,
                            size - 1
                        );
                        
                        ctx.strokeStyle = '#00000040';
                        ctx.lineWidth = 1;
                        ctx.strokeRect(
                            (this.current.x + x) * size,
                            (this.current.y + y) * size,
                            size,
                            size
                        );
                    }
                }
            }
        }
        
        // Draw grid
        ctx.strokeStyle = '#ffffff10';
        ctx.lineWidth = 0.5;
        for (let x = 0; x <= this.COLS; x++) {
            ctx.beginPath();
            ctx.moveTo(x * size, 0);
            ctx.lineTo(x * size, this.ROWS * size);
            ctx.stroke();
        }
        for (let y = 0; y <= this.ROWS; y++) {
            ctx.beginPath();
            ctx.moveTo(0, y * size);
            ctx.lineTo(this.COLS * size, y * size);
            ctx.stroke();
        }
    }
    
    drawNextQueue() {
        // Draw each piece in the queue
        for (let i = 0; i < Math.min(5, this.nextQueue.length); i++) {
            const canvas = document.getElementById(`next-piece-${i}`);
            if (!canvas) continue;
            
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            const piece = this.nextQueue[i];
            if (!piece) continue;
            
            this.drawPiecePreview(ctx, piece);
        }
    }
    
    drawHold() {
        const canvas = document.getElementById('hold');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (this.hold === null) return;
        
        const piece = { 
            type: this.hold, 
            matrix: this.PIECES[this.hold] 
        };
        this.drawPiecePreview(ctx, piece);
    }
    
    drawPiecePreview(ctx, piece) {
        const matrix = piece.matrix;
        const color = this.COLORS[piece.type];
        const blockSize = 20;
        const width = ctx.canvas.width;
        const height = ctx.canvas.height;
        
        const offsetX = (width - matrix[0].length * blockSize) / 2;
        const offsetY = (height - matrix.length * blockSize) / 2;
        
        for (let y = 0; y < matrix.length; y++) {
            for (let x = 0; x < matrix[y].length; x++) {
                if (matrix[y][x]) {
                    const screenX = offsetX + x * blockSize;
                    const screenY = offsetY + y * blockSize;
                    
                    ctx.fillStyle = color;
                    ctx.fillRect(screenX, screenY, blockSize, blockSize);
                    
                    ctx.strokeStyle = '#00000040';
                    ctx.lineWidth = 1;
                    ctx.strokeRect(screenX, screenY, blockSize, blockSize);
                }
            }
        }
    }
}

// Start the game when page loads
window.addEventListener('DOMContentLoaded', () => {
    window.tetris = new Tetris();
});