
        // Initialize GSAP
        gsap.registerPlugin(ScrollTrigger);
        
        // Loading Animation
        document.addEventListener('DOMContentLoaded', function() {
            const loader = document.querySelector('.loader');
            const loaderProgress = document.querySelector('.loader-progress');
            
            // Animate loader progress
            gsap.to(loaderProgress, {
                width: '100%',
                duration: 1.5,
                ease: 'power2.inOut',
                onComplete: () => {
                    // Hide loader
                    gsap.to(loader, {
                        opacity: 0,
                        duration: 0.5,
                        ease: 'power2.out',
                        onComplete: () => {
                            loader.style.display = 'none';
                            initAnimations();
                        }
                    });
                }
            });
        });
        
        function initAnimations() {
            // Animate hero elements with stagger
            gsap.from('.hero-title', {
                y: 50,
                opacity: 0,
                duration: 1.2,
                ease: 'power3.out',
                delay: 0.2
            });
            
            gsap.from('.subtitle', {
                y: 30,
                opacity: 0,
                duration: 1,
                ease: 'power3.out',
                delay: 0.5
            });
            
            gsap.from('.cta-button', {
                y: 30,
                opacity: 0,
                duration: 1,
                ease: 'power3.out',
                delay: 0.7
            });
            
            gsap.from('.image-placeholder', {
                scale: 0.8,
                opacity: 0,
                duration: 1.2,
                ease: 'power3.out',
                delay: 0.3
            });
            
            // Animate skill bars on scroll
            gsap.utils.toArray('.skill-level').forEach(bar => {
                gsap.to(bar, {
                    scrollTrigger: {
                        trigger: bar,
                        start: 'top 80%',
                        toggleActions: 'play none none none'
                    },
                    scaleX: 1,
                    duration: 1.5,
                    ease: 'power3.out'
                });
            });
            
            // Animate fade-in elements on scroll
            gsap.utils.toArray('.fade-in').forEach(element => {
                gsap.from(element, {
                    scrollTrigger: {
                        trigger: element,
                        start: 'top 85%',
                        toggleActions: 'play none none none'
                    },
                    y: 30,
                    opacity: 0,
                    duration: 1,
                    ease: 'power3.out'
                });
            });
            
            // Animate project cards on hover
            gsap.utils.toArray('.project-card').forEach(card => {
                card.addEventListener('mouseenter', () => {
                    gsap.to(card, {
                        y: -10,
                        duration: 0.3,
                        ease: 'power2.out'
                    });
                });
                
                card.addEventListener('mouseleave', () => {
                    gsap.to(card, {
                        y: 0,
                        duration: 0.3,
                        ease: 'power2.out'
                    });
                });
            });
            
            // Animate navigation links on hover
            gsap.utils.toArray('.nav-links a').forEach(link => {
                link.addEventListener('mouseenter', () => {
                    gsap.to(link, {
                        y: -2,
                        duration: 0.2,
                        ease: 'power2.out'
                    });
                });
                
                link.addEventListener('mouseleave', () => {
                    gsap.to(link, {
                        y: 0,
                        duration: 0.2,
                        ease: 'power2.out'
                    });
                });
            });
            
            // Form submission animation
            const contactForm = document.getElementById('contactForm');
            if (contactForm) {
                contactForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const submitBtn = this.querySelector('.cta-button');
                    const originalText = submitBtn.textContent;
                    
                    // Animate button on submit
                    gsap.to(submitBtn, {
                        scale: 0.95,
                        duration: 0.1,
                        yoyo: true,
                        repeat: 1,
                        onComplete: () => {
                            submitBtn.textContent = 'Message Sent!';
                            submitBtn.style.backgroundColor = '#4CAF50';
                            
                            // Reset after 2 seconds
                            setTimeout(() => {
                                submitBtn.textContent = originalText;
                                submitBtn.style.backgroundColor = '';
                                contactForm.reset();
                            }, 2000);
                        }
                    });
                });
            }
            
            // Text reveal animation for hero title
            const heroTitle = document.querySelector('.hero-title');
            if (heroTitle) {
                const text = heroTitle.textContent;
                heroTitle.innerHTML = '';
                
                for (let i = 0; i < text.length; i++) {
                    const span = document.createElement('span');
                    span.textContent = text[i];
                    span.style.display = 'inline-block';
                    span.style.opacity = '0';
                    heroTitle.appendChild(span);
                    
                    gsap.to(span, {
                        opacity: 1,
                        duration: 0.05,
                        delay: 0.1 + (i * 0.02),
                        ease: 'power2.out'
                    });
                }
            }
        }
        
        // Smooth scroll for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            });
        });